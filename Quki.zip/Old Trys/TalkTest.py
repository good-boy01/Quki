import gtts
from playsound import playsound

# به گوگل ریکوئست بدیم
tts = gtts.gTTS("Hi this is Quki Assistant ! This is a text to speach test , test number 6")
# فایل سیو شه 
tts.save("test.mp3")
# آدیو پخش بشه
playsound("test.mp3")

#تست شماره 6 با موفقیت انجام شد 
