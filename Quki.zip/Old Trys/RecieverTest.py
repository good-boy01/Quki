import speech_recognition as sr
import sys

# اسم فایل رو بخونه
filename = "VoiceTest1.wav"

# رکوگنایزر رو تعریف کنیم
r = sr.Recognizer()

# فایل باز بشه
with sr.AudioFile(filename) as source:
    # آدیو تو مموری لود شه
    audio_data = r.record(source)
    # آدیو از صدا به متن تبدیل شه
    text = r.recognize_google(audio_data)
    print(text)