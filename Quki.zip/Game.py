#کتاب خونه های استفاده شده
import pygame
from pygame.locals import *
import sys
import math

pygame.init()
pygame.mixer.init()

#تنظیمات صفحه 
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Air Hockey Game")

#رنگ های آر جی بی , پالت از وب سایت کالر هانت
BLUE = (2, 84, 100)
ORANGE = (229, 124, 35)
YELLOW = (232, 170, 66)
WHITE = (248, 241, 241)
BLACK = (0,0,0)

#تنظیمات بازیکنان و توپ
player1_radius = 25
player1_x = player1_radius + 10
player1_y = height // 2
player2_radius = 25
player2_x = width - player2_radius - 10
player2_y = height // 2
ball_radius = 18
ball_x = width // 2
ball_y = height // 2
ball_speed = 0.4
ball_direc = math.pi / 4 

#تنظیمات دروازه ها
goal_width = 10
goal_height = 100
goal1_x = 0
goal1_y = height // 2 - goal_height // 2
goal2_x = width - goal_width
goal2_y = height // 2 - goal_height // 2

#تنظیمات بورد نمایش امتیازات
score1 = 0
score2 = 0
font = pygame.font.Font(None, 36)
score_text = font.render(f"{score1} - {score2}", True, BLUE)
score_text_rect = score_text.get_rect(center=(width // 2, 30))

#تنظیمات منو 
menu_font = pygame.font.Font(None, 48)
menu_text = menu_font.render("Choose Mode:", True, BLUE)
menu_text_rect = menu_text.get_rect(center=(width // 2, height // 2 - 50))
normal_button = menu_font.render("Normal", True, BLUE)
normal_button_rect = normal_button.get_rect(center=(width // 2, height // 2))
hard_button = menu_font.render("Hard", True, BLUE)
hard_button_rect = hard_button.get_rect(center=(width // 2, height // 2 + 50))

#بولین هایی که برای تغییرات اساسی استفاده میشود , مثلا این که توپ وقتی برگشت سر جاش حرکت نکنه یا امتیاز به ده رسید برنامه دیگه ران نشه 
is_menu = True
is_normal_mode = False
is_hard_mode = False
Run = True
ball_moving = False
#تنظیمات موقعیت اسپان شدن توپ برای اول بازی و ووقتی که کسی گل می زند
if score1 == 0 and score2 == 0:
    ball_moving = True
else:
    ball_moving = False

pygame.mixer.music.load("Tetris Theme Song.mp3")
pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play()

#لوپ برنامه
while Run:
    #ایونت ها و دکمه های منو
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == MOUSEBUTTONDOWN:
            if event.button == 1:
                if is_menu:
                    mouse_pos = pygame.mouse.get_pos()
                    if normal_button_rect.collidepoint(mouse_pos):
                        is_normal_mode = True
                        is_menu = False
                    elif hard_button_rect.collidepoint(mouse_pos):
                        is_hard_mode = True
                        is_menu = False
    #نمایش منو
    if is_menu:
        
        screen.fill(YELLOW)
        screen.blit(menu_text, menu_text_rect)
        screen.blit(normal_button, normal_button_rect)
        screen.blit(hard_button, hard_button_rect)
        pygame.display.update()
        continue
    #وارد شدن به حالن نرمال
    if is_normal_mode:
        #فاصله بازیکنان با توپ
        player1_dist = math.sqrt((ball_x - player1_x) ** 2 + (ball_y - player1_y) ** 2)
        player2_dist = math.sqrt((ball_x - player2_x) ** 2 + (ball_y - player2_y) ** 2)

        #جای گذاری توپ وقتی کسی گل خورده و جهت دهی بهش
        if player1_dist <= player1_radius + ball_radius:
            collision_angle = math.atan2(ball_y - player1_y, ball_x - player1_x)
            ball_direc = 2 * collision_angle - ball_direc
            ball_moving = True

        if player2_dist <= player2_radius + ball_radius:
            collision_angle = math.atan2(ball_y - player2_y, ball_x - player2_x)
            ball_direc = 2 * collision_angle - ball_direc
            ball_moving = True

        
        #دکمه ها برای حرکت بازی کنان
        keys = pygame.key.get_pressed()
        if keys[K_a] and player1_x - player1_radius > 0:
            player1_x -= 1
        if keys[K_d] and player1_x + player1_radius < width // 2 - 100:
            player1_x += 1
        if keys[K_LEFT] and player2_x - player2_radius > width // 2 + 100:
            player2_x -= 1
        if keys[K_RIGHT] and player2_x + player2_radius < width:
            player2_x += 1
        if keys[K_w] and player1_y - player1_radius > 0:
            player1_y -= 1
        if keys[K_s] and player1_y + player1_radius < height:
            player1_y += 1
        if keys[K_UP] and player2_y - player2_radius > 0:
            player2_y -= 1
        if keys[K_DOWN] and player2_y + player2_radius < height:
            player2_y += 1
        
        

        #حالت سخت که ن داریم
    if is_hard_mode:
        pass
    #تنظیم حرکت توپ
    if ball_moving == True :
        if ball_x < width // 2:
            ball_x += ball_speed * math.cos(ball_direc)
            ball_y += ball_speed * math.sin(ball_direc)
        else:
            if ball_speed < 0.4 + 0.2:
                ball_speed += 0.2
            ball_x += ball_speed * math.cos(ball_direc)
            ball_y += ball_speed * math.sin(ball_direc)

    

    #چک کردن برخورد با مرز های اسکرین
    if ball_x - ball_radius <= 0 or ball_x + ball_radius >= width:
        ball_direc = math.pi - ball_direc
    if ball_y - ball_radius <= 0 or ball_y + ball_radius >= height:
        ball_direc = -ball_direc


    # برخورد با بازیکنان
    player1_dist = math.sqrt((ball_x - player1_x) ** 2 + (ball_y - player1_y) ** 2)
    if player1_dist <= player1_radius + ball_radius:
        ball_moving = True
        collision_angle = math.atan2(ball_y - player1_y, ball_x - player1_x)
        ball_direc = collision_angle - ball_direc
        ball_x += math.cos(collision_angle) * (player1_radius + ball_radius - player1_dist + 1)
        ball_y += math.sin(collision_angle) * (player1_radius + ball_radius - player1_dist + 1)

    player2_dist = math.sqrt((ball_x - player2_x) ** 2 + (ball_y - player2_y) ** 2)
    if player2_dist <= player2_radius + ball_radius:
        ball_moving = True
        collision_angle = math.atan2(ball_y - player2_y, ball_x - player2_x)
        ball_direc = collision_angle - ball_direc
        ball_x += math.cos(collision_angle) * (player2_radius + ball_radius - player2_dist)
        ball_y += math.sin(collision_angle) * (player2_radius + ball_radius - player2_dist)



    #امتیاز دهی و جایگذاری توپ بعد از امتیاز دهی
    if ball_x - ball_radius <= goal_width and goal1_y <= ball_y <= goal1_y + goal_height:
        score2 += 1
        ball_x = 250
        ball_y = height // 2
        ball_moving = False
    
    if ball_x + ball_radius >= width - goal_width and goal2_y <= ball_y <= goal2_y + goal_height:
        score1 += 1
        ball_x = width-250
        ball_y = height // 2
        ball_moving = False

        
    
    


        


            

        #سیستم اعلام برنده
        if score2 == 10:
            screen.fill(WHITE)
            winner_text = font.render("Player 2 Wins!", True, BLUE)
            winner_text_rect = winner_text.get_rect(center=(width // 2, height // 2))
            restart_text = font.render("Run again to restart", True, BLUE)
            restart_text_rect = restart_text.get_rect(center=(width // 2, height // 2 + 50))
            Run = False
   
        if score1 == 10:
            screen.fill(WHITE)
            winner_text = font.render("Player 1 Wins!", True, BLUE)
            winner_text_rect = winner_text.get_rect(center=(width // 2, height // 2))
            restart_text = font.render("Run Again to restart ", True, BLUE)
            restart_text_rect = restart_text.get_rect(center=(width // 2, height // 2 + 50))
            Run = False

    #نمایش امتیازات
    score_text = font.render(f"{score1} - {score2}", True, WHITE)

    #کشیدن اشکال مورد نیاز
    screen.fill(BLUE)
    pygame.draw.rect(screen, ORANGE, (goal1_x, goal1_y, goal_width, goal_height))
    pygame.draw.rect(screen, YELLOW, (goal2_x, goal2_y, goal_width, goal_height))
    pygame.draw.circle(screen, ORANGE, (int(player1_x), int(player1_y)), player1_radius)
    pygame.draw.circle(screen, YELLOW, (int(player2_x), int(player2_y)), player2_radius)
    pygame.draw.circle(screen, WHITE, (int(ball_x), int(ball_y)), ball_radius)
    screen.blit(score_text, score_text_rect)

    
    pygame.display.update()

   
   


#رنگ ها از وبسایت COLORHUNT
#پروژه پایان سال ایلیا خان محمدی 
#بازی  AIRHOCKEY